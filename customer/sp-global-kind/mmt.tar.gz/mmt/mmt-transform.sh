#!/bin/sh
# 
# The first step in migrating your source MSR system to a target MSR system is to verify the configuration of the source system.

# Variables
MKE_URL="https://ec2-3-145-17-210.us-east-2.compute.amazonaws.com"
MKE_SRC_URL="https://ec2-3-146-221-81.us-east-2.compute.amazonaws.com"
MKE_USR="admin"
MMT_MODE="copy"
MMT_VERS="2.0.1"
MMT_POD="mmt"
MSR_30_DEST=""		# Full MSR instance name
LOCAL_DIR="/home/docker/mmt/data"
#
# To get the replica ID, log into the source MSR and run this command:
#    docker ps --format '{{.Names}}' -f name=dtr-rethink | cut -f 3 -d '-'
#
REPLICA_ID="31c927822913"
MSR_REGISTRY_CONTAINER="dtr-registry-${REPLICA_ID}"

# We need to prompt for this one
read -sp "Enter the MKE admin user password: " MKE_PASSWORD
echo

# Run the transform step
kubectl exec ${MMT_POD} -- \
	./mmt transform metadata msr \
	--fullname ${MSR_30_DEST}
	--storage-mode ${MMT_MODE} \
	--enzipassword ${MKE_PASSWORD} \
	/migration

